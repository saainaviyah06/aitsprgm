const Blogs=()=>{
    return <h1>BlogArticle</h1>;
};
export default Blogs;